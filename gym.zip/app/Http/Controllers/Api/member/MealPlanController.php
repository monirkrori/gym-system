<?php

namespace App\Http\Controllers\Api\member;

use App\Models\User;
use App\Models\MealPlan;
use App\Http\Controllers\Controller;
use App\Models\Traits\ApiResponseTrait;
use App\Http\Requests\member\SubscribeMealPlanRequest;

class MealPlanController extends Controller
{
    use ApiResponseTrait;

    // Subscribe a user to a meal plan.

    public function subscribe(SubscribeMealPlanRequest $request)
    {
        // Check if the user exists
        $user = User::find($request->user_id);
        if (!$user) {
            return $this->errorResponse('User not found.', 404);
        }

        // Check if the meal plan exists
        $mealPlan = MealPlan::find($request->meal_plan_id);
        if (!$mealPlan) {
            return $this->errorResponse('Meal plan not found.', 404);
        }

        // Check if the user is already subscribed to this meal plan
        if ($user->mealPlans()->where('meal_plan_id', $request->meal_plan_id)->exists()) {
            return $this->errorResponse('User is already subscribed to this meal plan.');
        }

        // Subscribe the user to the meal plan
        $user->mealPlans()->attach($request->meal_plan_id);

        return $this->succsessResponse(null, 'Successfully subscribed to the meal plan.');
    }
//--------------------------------------------------------------------------------//

    // Get the meal plans subscribed by a user.

    public function getUserMealPlans($userId)
    {
        $user = User::find($userId);
        if (!$user) {
            return $this->errorResponse('User not found.', 404);
        }

        $mealPlans = $user->mealPlans;

        return $this->succsessResponse($mealPlans, 'Meal plans retrieved successfully.');
    }
}
