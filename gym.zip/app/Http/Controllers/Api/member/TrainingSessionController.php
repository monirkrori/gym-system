<?php

namespace App\Http\Controllers\Api\member;

use Carbon\Carbon;
use App\Models\Booking;
use Illuminate\Http\Request;
use App\Models\UserMembership;
use App\Models\TrainingSession;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Models\Traits\ApiResponseTrait;
use App\Http\Requests\member\BookSessionRequest;
use App\Http\Requests\member\CancelSessionRequest;

class TrainingSessionController extends Controller
{
    use ApiResponseTrait;

    // Display available training sessions for the member
    public function listSessions(Request $request)
    {
        $user = Auth::user();

    // Retrieve sessions available for the user based on their membership level
    $sessions = TrainingSession::where('status', 'scheduled')
        ->where('current_capacity', '<', 'max_capacity')
        ->where('start_time', '>', now())  // Only future sessions
        ->get();

    return $this->succsessResponse($sessions, 'Available sessions retrieved successfully.');
}
//--------------------------------------------------------------------------------//

    public function show($id)
    {
        // Find the session by ID
        $session = TrainingSession::findOrFail($id);

        if (!$session) {
            return response()->json(['message' => 'Training session not found'], 404);
        }

        return response()->json(['status' => $session->status]);
    }


}
