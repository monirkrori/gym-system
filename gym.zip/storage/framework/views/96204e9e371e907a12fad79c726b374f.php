<?php $__env->startSection('title', 'إضافة مدرب'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="mb-4">إضافة مدرب جديد</h1>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('admin.trainers.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="user_id" class="form-label">المستخدم</label>
                <select class="form-select" name="user_id" id="user_id" required>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="specialization" class="form-label">التخصص</label>
                <input type="text" class="form-control" id="specialization" name="specialization" required>
            </div>
            <div class="mb-3">
                <label for="experience_years" class="form-label">سنوات الخبرة</label>
                <input type="number" class="form-control" id="experience_years" name="experience_years" required>
            </div>
            <div class="mb-3">
                <label for="status" class="form-label">الحالة</label>
                <select class="form-select" name="status" id="status" required>
                    <option value="available">نشط</option>
                    <option value="unavailable">غير نشط</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">إضافة</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\gym-system\resources\views/trainers/create.blade.php ENDPATH**/ ?>