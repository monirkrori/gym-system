<?php $__env->startSection('title', 'إضافة خطة اشتراك جديدة'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <h1 class="h3 mb-4 text-gray-800"><i class="bi bi-plus-circle me-2"></i> إضافة خطة اشتراك جديدة</h1>
         <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <form action="<?php echo e(route('admin.membership-plans.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="name" class="form-label">اسم الخطة</label>
                            <input type="text" id="name" name="name" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label for="price" class="form-label">السعر</label>
                            <input type="number" id="price" name="price" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label for="duration_month" class="form-label">مدة الاشتراك (بالأشهر)</label>
                            <input type="number" id="duration_month" name="duration_month" class="form-control" required value="<?php echo e(old('duration_month', $membershipPlan->duration_month ?? 1)); ?>">
                        </div>
                        <div class="col-md-6">
                            <label for="status" class="form-label">الحالة</label>
                            <select id="status" name="status" class="form-select">
                                <option value="active" selected>نشطة</option>
                                <option value="expired">غير نشطة</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label for="description" class="form-label">الوصف</label>
                            <textarea id="description" name="description" class="form-control"></textarea>
                        </div>
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary">إضافة الخطة</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\gym-system\resources\views/membership-plans/create.blade.php ENDPATH**/ ?>